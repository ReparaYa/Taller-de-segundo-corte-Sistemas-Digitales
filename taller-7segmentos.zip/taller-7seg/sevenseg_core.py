"""Lógica pura del decodificador de 7 segmentos (sin MyHDL).

Orden de bits de cada patrón: a b c d e f g  (a = bit más significativo).
"""

SEGMENTOS = "abcdefg"


def read_table(path):
    """Lee un .txt con 16 líneas de 7 bits y devuelve una tupla de 16 enteros."""
    filas = []
    with open(path) as f:
        for n, linea in enumerate(f, 1):
            s = linea.strip()
            if not s:
                continue
            if len(s) != 7 or set(s) - {"0", "1"}:
                raise ValueError(f"línea {n}: se esperaban 7 bits, se leyó {s!r}")
            filas.append(int(s, 2))
    if len(filas) != 16:
        raise ValueError(f"se esperaban 16 líneas, hay {len(filas)}")
    return tuple(filas)


def decode(table, valor):
    """Devuelve el patrón de 7 bits (entero) para un valor de 4 bits."""
    if not 0 <= valor <= 15:
        raise ValueError("el valor debe estar entre 0 y 15")
    return table[valor]


def segmentos_encendidos(patron):
    """Ej.: 0b0110000 -> 'bc'."""
    return "".join(s for i, s in enumerate(SEGMENTOS) if patron & (1 << (6 - i)))


def render_ascii(patron):
    """Dibujo ASCII de 3 líneas del patrón (útil para depurar la tabla)."""
    on = {s: bool(patron & (1 << (6 - i))) for i, s in enumerate(SEGMENTOS)}
    top = " _ " if on["a"] else "   "
    mid = ("|" if on["f"] else " ") + ("_" if on["g"] else " ") + ("|" if on["b"] else " ")
    bot = ("|" if on["e"] else " ") + ("_" if on["d"] else " ") + ("|" if on["c"] else " ")
    return "\n".join([top, mid, bot])
