"""Pruebas unitarias (pytest). Ejecutar con:  pytest -v"""
from pathlib import Path

import pytest

from sevenseg_core import decode, read_table, segmentos_encendidos

TABLA = Path(__file__).with_name("tabla_decodificacion.txt")

# Especificación independiente de la tabla: segmentos encendidos por valor.
ESPERADO = {
    0: "abcdef", 1: "bc", 2: "abdeg", 3: "abcdg", 4: "bcfg",
    5: "acdfg", 6: "acdefg", 7: "abc", 8: "abcdefg", 9: "abcdfg",
    10: "g", 11: "d", 12: "a", 13: "abfg", 14: "dg", 15: "",
}


@pytest.fixture(scope="module")
def table():
    return read_table(TABLA)


@pytest.mark.parametrize("valor,segs", sorted(ESPERADO.items()))
def test_patron(table, valor, segs):
    assert segmentos_encendidos(decode(table, valor)) == segs


def test_formato_16_lineas_7_bits():
    lineas = [l for l in TABLA.read_text().splitlines() if l.strip()]
    assert len(lineas) == 16
    assert all(len(l) == 7 and set(l) <= {"0", "1"} for l in lineas)


def test_patrones_distintos(table):
    assert len(set(table)) == 16


def test_6_y_9_cerrados_y_1_a_la_derecha(table):
    assert "a" in segmentos_encendidos(table[6])
    assert "d" in segmentos_encendidos(table[9])
    assert segmentos_encendidos(table[1]) == "bc"


@pytest.mark.parametrize("malo", [-1, 16])
def test_fuera_de_rango(table, malo):
    with pytest.raises(ValueError):
        decode(table, malo)


def test_simulacion_myhdl_sin_errores(table):
    pytest.importorskip("myhdl")
    from sevensegdec import testbench

    errores = []
    testbench(table, errores).run_sim(duration=200, quiet=1)
    assert errores == []
