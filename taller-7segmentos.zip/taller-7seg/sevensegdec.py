"""Decodificador de 7 segmentos con MyHDL: simulación + generación de HDL.

Uso:
    python sevensegdec.py tabla_decodificacion.txt             # VHDL (defecto)
    python sevensegdec.py tabla_decodificacion.txt -verilog    # Verilog
"""
import argparse

from myhdl import Signal, block, always_comb, delay, instance, intbv

from sevenseg_core import read_table


@block
def sevensegdec(bcd, sseg, lut):
    """LUT combinacional: sseg = lut[bcd]."""

    @always_comb
    def rom():
        sseg.next = lut[int(bcd)]

    return rom


@block
def testbench(table, errores=None):
    """Recorre 0..15 y compara sseg con la tabla. Guarda los fallos en `errores`."""
    errores = errores if errores is not None else []
    bcd = Signal(intbv(0)[4:])
    sseg = Signal(intbv(0)[7:])
    dut = sevensegdec(bcd, sseg, table)

    @instance
    def estimulo():
        for v in range(16):
            bcd.next = v
            yield delay(10)
            if int(sseg) != table[v]:
                errores.append(v)
                print(f"ERROR: bcd={v:2d} sseg={int(sseg):07b} esperado={table[v]:07b}")
            else:
                print(f"OK:    bcd={v:2d} sseg={int(sseg):07b}")

    return dut, estimulo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("tabla")
    ap.add_argument("-verilog", action="store_true", help="generar Verilog en vez de VHDL")
    args = ap.parse_args()

    table = read_table(args.tabla)

    # 1) Simulación (genera testbench.vcd)
    tb = testbench(table)
    tb.config_sim(trace=True)
    tb.run_sim(duration=16 * 10 + 10)

    # 2) Generación de HDL (carpeta hdl/)
    bcd = Signal(intbv(0)[4:])
    sseg = Signal(intbv(0)[7:])
    dut = sevensegdec(bcd, sseg, table)
    dut.convert(hdl="Verilog" if args.verilog else "VHDL", path="hdl")


if __name__ == "__main__":
    main()
