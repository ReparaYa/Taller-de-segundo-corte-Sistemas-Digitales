# Taller segundo corte — Decodificador de 7 segmentos

## 1. Tabla de decodificación

Archivo: [`tabla_decodificacion.txt`](tabla_decodificacion.txt). 16 líneas, 7 bits por línea, orden `abcdefg` (a = bit más significativo, 1 = segmento encendido).

| Entrada | Símbolo | abcdefg | Segmentos |
|---|---|---|---|
| 0 | 0 | 1111110 | a b c d e f |
| 1 | 1 | 0110000 | b c |
| 2 | 2 | 1101101 | a b d e g |
| 3 | 3 | 1111001 | a b c d g |
| 4 | 4 | 0110011 | b c f g |
| 5 | 5 | 1011011 | a c d f g |
| 6 | 6 | 1011111 | a c d e f g |
| 7 | 7 | 1110000 | a b c |
| 8 | 8 | 1111111 | todos |
| 9 | 9 | 1111011 | a b c d f g |
| 10 | `-` (guion medio) | 0000001 | g |
| 11 | `_` (guion bajo) | 0001000 | d |
| 12 | `¯` (barra superior) | 1000000 | a |
| 13 | `°` (grado) | 1100011 | a b f g |
| 14 | `=` (igual) | 0001001 | d g |
| 15 | (apagado) | 0000000 | ninguno |

### Decisiones de diseño
- **6 y 9 cerrados:** el 6 enciende el segmento superior (`a`) y el 9 el inferior (`d`), para distinguirlos mejor del `b`/`g` y del `q` en un display pequeño.
- **El 1 se dibuja a la derecha** (segmentos `b` y `c`), que es la convención estándar.
- **10–15 sin letras A–F** (justificación en una frase cada una):
  - 10 `-`: signo menos / valor negativo.
  - 11 `_`: marcador de "espacio" o cursor bajo.
  - 12 `¯`: contraparte superior del guion bajo, útil para indicar "overflow".
  - 13 `°`: símbolo de grado, para temperaturas.
  - 14 `=`: signo igual, para resultados.
  - 15 apagado: estado en blanco / display vacío.

## 2. Comandos usados

```bash
pip install myhdl pytest
python sevensegdec.py tabla_decodificacion.txt            # simulación + VHDL
python sevensegdec.py tabla_decodificacion.txt -verilog   # (opcional) Verilog
pytest -v
```
> Ajuste este bloque al comando exacto que usted ejecutó.

## 3. Resultados de simulación

> **Pegue aquí la salida real** de su ejecución (líneas `OK: bcd=...`) y las capturas del VCD (`testbench.vcd`) abierto en GTKWave o vc.drom.io.

### Qué verifica el testbench
Aplica los 16 valores de `bcd` (0 a 15), espera 10 unidades de tiempo para que la lógica combinacional se estabilice y compara `sseg` con la fila correspondiente de la tabla. Solo imprime `ERROR` cuando hay diferencia; como el decodificador se construye con esa misma tabla, no aparecen errores cuando la tabla es consistente (16 filas válidas y la LUT las reproduce).

### Qué es `sseg`
Un bus de 7 bits `abcdefg`; cada bit activa un segmento del display (1 = encendido). Ejemplo: `bcd=1` → `sseg=0110000` → se encienden `b` y `c`.

### Interpretación del VCD
> Complete con lo que observe: `bcd` cuenta de 0 a 15 cada 10 unidades de tiempo y `sseg` cambia en el mismo instante (lógica combinacional, sin reloj ni retardo propio). Compare 3 o 4 valores con la tabla.

### HDL generado
Enlace: [`hdl/sevensegdec.vhd`](hdl/sevensegdec.vhd) (suba la carpeta `hdl/` generada).
La LUT `lut[bcd]` se convierte en una sentencia `case`/`with ... select` con 16 ramas: cada valor de `bcd` selecciona una constante de 7 bits. En hardware se sintetiza como lógica combinacional pura: cada bit de `sseg` es una función booleana de los 4 bits de entrada (una ROM de 16×7 o 7 mapas de Karnaugh).

## 4. Pruebas unitarias
- `sevenseg_core.py`: lógica pura (leer tabla, decodificar), sin MyHDL.
- `sevensegdec.py`: bloque MyHDL, testbench, simulación y conversión a HDL.
- `test_sevenseg.py`: pytest con `@pytest.mark.parametrize` para los 16 casos, validación del formato del archivo, 6/9 cerrados, 1 a la derecha, rango inválido y una prueba que ejecuta la simulación MyHDL y exige cero errores.

Se eligió **pytest** frente a `unittest` por la parametrización directa y los mensajes de fallo más claros.
